"""Atelier Collection Compact — outils de patronnage.

Charger dans Python :  exec(open('/chemin/vers/patron_tools.py').read())
Dépendances : reportlab (PDF). Sorties dans /mnt/data par défaut.

Unités : centimètres. Repère d'une pièce : origine en haut à gauche, x vers la droite, y vers le BAS.

Une pièce est un dict :
    {
      "nom": "Jupe devant", "couper": "1 au pli", "matiere": "lin écru",
      "contour": [(x, y), ...],          # ligne de couture (contour FINI), polygone fermé
      "couture": 1.0 ou [v0, v1, ...],   # valeur de couture par bord (bord i = point i -> i+1) ; 0 sur une pliure
      "droit_fil": ((x1, y1), (x2, y2)),
      "pliure": ((x1, y1), (x2, y2)) ou None,
      "crans": [(x, y), ...],            # points sur le contour fini
      "lignes": [[(x, y), ...], ...],    # lignes internes : pinces, repères, ajours
      "cotes": [((x1, y1), (x2, y2), "texte"), ...],
    }
Le tableau de cotes (.md) fait foi ; ces fichiers en sont la mise au net.
"""
import math, os

DOSSIER = next((d for d in ("/mnt/user-data/outputs", "/mnt/data") if os.path.isdir(d)), os.getcwd())


def _p(nom):
    return nom if os.path.isabs(nom) else os.path.join(DOSSIER, nom)


# ------------------------------------------------------------------ barème
BAREME = {
    "tour_poitrine":      [80, 84, 88, 92, 96, 100, 104],
    "tour_taille":        [62, 66, 70, 74, 78, 82, 86],
    "tour_hanches":       [88, 92, 96, 100, 104, 108, 112],
    "stature":            [166, 167, 168, 169, 170, 171, 172],
    "long_taille_dos":    [40.0, 40.5, 41.0, 41.5, 42.0, 42.5, 43.0],
    "long_taille_devant": [42.6, 43.3, 44.0, 44.7, 45.4, 46.1, 46.8],
    "carrure_dos":        [33, 34, 35, 36, 37, 38, 39],
    "carrure_devant":     [31, 32, 33, 34, 35, 36, 37],
    "long_epaule":        [11.9, 12.2, 12.5, 12.8, 13.1, 13.4, 13.7],
    "tour_encolure":      [34, 35, 36, 37, 38, 39, 40],
    "hauteur_poitrine":   [24.4, 25.2, 26.0, 26.8, 27.6, 28.4, 29.2],
    "ecart_poitrine":     [17.0, 17.5, 18.0, 18.5, 19.0, 19.5, 20.0],
    "long_bras":          [57.4, 58.2, 59.0, 59.8, 60.6, 61.4, 62.2],
    "tour_bras":          [25.0, 26.5, 28.0, 29.5, 31.0, 32.5, 34.0],
    "tour_poignet":       [15.0, 15.5, 16.0, 16.5, 17.0, 17.5, 18.0],
    "hauteur_hanches":    [19.5, 19.75, 20.0, 20.25, 20.5, 20.75, 21.0],
    "montant":            [26.2, 26.6, 27.0, 27.4, 27.8, 28.2, 28.6],
    "taille_sol":         [103.0, 103.5, 104.0, 104.5, 105.0, 105.5, 106.0],
    "entrejambe":         [76.8, 76.9, 77.0, 77.1, 77.2, 77.3, 77.4],
    "taille_genou":       [57.2, 57.6, 58.0, 58.4, 58.8, 59.2, 59.6],
}
TAILLES = [34, 36, 38, 40, 42, 44, 46]


def mensurations(taille=38, **sur_mesure):
    """Mensurations d'une taille du barème ; les valeurs sur mesure passées en argument priment."""
    if taille not in TAILLES:
        raise ValueError("Taille hors barème (34 à 46) : au-delà, la gradation n'est plus linéaire.")
    i = TAILLES.index(taille)
    m = {k: v[i] for k, v in BAREME.items()}
    m.update(sur_mesure)
    m["taille"] = taille
    return m


# ------------------------------------------------------------------ géométrie
def longueur(pts, ferme=False):
    pts = list(pts) + ([pts[0]] if ferme else [])
    return sum(math.dist(pts[i], pts[i + 1]) for i in range(len(pts) - 1))


def longueur_bord(piece, i, j):
    """Longueur du contour fini du point i au point j (sens du contour)."""
    c = piece["contour"]
    n = len(c)
    tot, k = 0.0, i
    while k != j:
        tot += math.dist(c[k], c[(k + 1) % n])
        k = (k + 1) % n
    return tot


def _aire(pts):
    return sum(pts[i][0] * pts[(i + 1) % len(pts)][1] - pts[(i + 1) % len(pts)][0] * pts[i][1] for i in range(len(pts))) / 2


def _nettoie(pts):
    out = []
    for p in pts:
        if not out or math.dist(out[-1], p) > 1e-6:
            out.append(tuple(map(float, p)))
    if len(out) > 1 and math.dist(out[0], out[-1]) < 1e-6:
        out.pop()
    return out


def _valeurs_couture(piece):
    n = len(piece["contour"])
    v = piece.get("couture", 1.0)
    return [float(v)] * n if isinstance(v, (int, float)) else [float(x) for x in v]


def contour_coupe(piece):
    """Contour de coupe = contour fini décalé vers l'extérieur de la valeur de couture de chaque bord."""
    c = _nettoie(piece["contour"])
    piece["contour"] = c
    s = _valeurs_couture(piece)
    n = len(c)
    signe = 1 if _aire(c) > 0 else -1
    lignes = []
    for i in range(n):
        (x1, y1), (x2, y2) = c[i], c[(i + 1) % n]
        dx, dy = x2 - x1, y2 - y1
        L = math.hypot(dx, dy)
        nx, ny = (dy / L, -dx / L) if signe > 0 else (-dy / L, dx / L)
        lignes.append(((x1 + nx * s[i], y1 + ny * s[i]), (x2 + nx * s[i], y2 + ny * s[i]), (nx, ny)))
    out = []
    smax = max(s) if s else 1
    for i in range(n):
        a1, a2, na = lignes[i - 1]
        b1, b2, nb = lignes[i]
        d1 = (a2[0] - a1[0], a2[1] - a1[1]); d2 = (b2[0] - b1[0], b2[1] - b1[1])
        cr = d1[0] * d2[1] - d1[1] * d2[0]
        if abs(cr) < 1e-9:
            out.append(((a2[0] + b1[0]) / 2, (a2[1] + b1[1]) / 2))
            continue
        t = ((b1[0] - a1[0]) * d2[1] - (b1[1] - a1[1]) * d2[0]) / cr
        p = (a1[0] + t * d1[0], a1[1] + t * d1[1])
        if math.dist(p, c[i]) > 3 * smax + 0.5:      # angle très aigu : biseau
            out += [a2, b1]
        else:
            out.append(p)
    return out


def courbe(p0, p1, p2, n=12):
    """Courbe de Bézier quadratique échantillonnée (p1 = point de contrôle), p0 exclu."""
    return [((1 - t) ** 2 * p0[0] + 2 * (1 - t) * t * p1[0] + t * t * p2[0],
             (1 - t) ** 2 * p0[1] + 2 * (1 - t) * t * p1[1] + t * t * p2[1]) for t in [k / n for k in range(1, n + 1)]]


def controle(nom, attendu, mesure, tol=0.3):
    ok = abs(attendu - mesure) <= tol
    return {"controle": nom, "attendu": round(attendu, 2), "mesure": round(mesure, 2), "ok": ok}


def tableau_controles(lignes):
    t = "| Contrôle | Attendu | Mesuré | |\n|---|---|---|---|\n"
    for l in lignes:
        t += f"| {l['controle']} | {l['attendu']} | {l['mesure']} | {'✅' if l['ok'] else '❌'} |\n"
    return t


# ------------------------------------------------------------------ blocs
def bloc_jupe_droite(m, longueur=None, devant=True, aisance_taille=2, aisance_hanches=4, au_pli=True, couture_ourlet=4):
    """Demi-panneau de jupe droite (ajusté). Répartition de la reprise totale (devant + dos) :
    côté 50 %, pince dos 35 %, pince devant 15 %. Une pince de plus de 3 cm est dédoublée."""
    L = longueur or m["taille_genou"]
    w = m["tour_hanches"] / 4 + aisance_hanches / 4
    r = w - (m["tour_taille"] / 4 + aisance_taille / 4)      # reprise par panneau
    R = 2 * r                                                # reprise totale devant + dos
    cote = 0.25 * R
    pince = (0.15 if devant else 0.35) * R
    hh = m["hauteur_hanches"]
    contour = [(0, 0), (w - cote, 0)]
    contour += courbe((w - cote, 0), (w, hh * 0.25), (w, hh), 10)
    contour += [(w, L), (0, L)]
    n = len(contour)
    milieu_seam = 0 if (devant and au_pli) else 1.5
    couture = [1.0] + [1.5] * 11 + [couture_ourlet, milieu_seam]
    couture = couture[:n] if len(couture) >= n else couture + [1.0] * (n - len(couture))
    long_pince = 10 if devant else 14
    nb = 2 if pince > 3 else 1
    lignes = []
    for k in range(nb):
        xd = (w - cote) * ((0.45 if nb == 1 else (0.35 + 0.25 * k)))
        d = pince / nb
        lignes.append([(xd - d / 2, 0), (xd, long_pince - 2 * k), (xd + d / 2, 0)])
    piece = {
        "nom": "Jupe devant" if devant else "Jupe dos",
        "couper": "1 au pli" if (devant and au_pli) else "2 (1 paire)",
        "matiere": "",
        "contour": contour, "couture": couture,
        "droit_fil": ((w * 0.72, L * 0.3), (w * 0.72, L * 0.85)),
        "pliure": ((0, 0), (0, L)) if (devant and au_pli) else None,
        "crans": [(w, hh)],
        "lignes": lignes,
        "cotes": [((0, -0.01), (w - cote, -0.01), f"{w - cote:.1f}"), ((0, hh), (w, hh), f"hanches {w:.1f}"),
                  ((w + 0.01, 0), (w + 0.01, L), f"L {L:.1f}")],
        "_info": {"largeur": w, "reprise_panneau": r, "cote": cote, "pince": pince, "taille_finie_demi": w - cote - pince},
    }
    return piece


def secteur_anneau(tour_haut, tour_bas, longueur, nb_les=4, nom="Lé de jupe", couture=1.0, ourlet=2.0, n=24):
    """Lé de jupe en tronc de cône. Retourne la pièce et ses cotes (rayon intérieur, rayon d'ourlet, angle)."""
    c1, c2 = tour_haut / nb_les, tour_bas / nb_les
    if abs(c2 - c1) < 1e-6:
        contour = [(0, 0), (c1, 0), (c1, longueur), (0, longueur)]
        info = {"rectangle": True}
    else:
        theta = (c2 - c1) / longueur
        R1 = c1 / theta; R2 = R1 + longueur
        a0 = -theta / 2
        haut = [(R1 * math.sin(a0 + theta * k / n), R1 * math.cos(a0 + theta * k / n)) for k in range(n + 1)]
        bas = [(R2 * math.sin(a0 + theta * k / n), R2 * math.cos(a0 + theta * k / n)) for k in range(n, -1, -1)]
        pts = haut + bas
        minx = min(p[0] for p in pts); miny = min(p[1] for p in pts)
        contour = [(x - minx, y - miny) for x, y in pts]
        info = {"rayon_interieur": R1, "rayon_ourlet": R2, "angle_degres": math.degrees(theta)}
    m = len(contour)
    cs = [couture] * m
    if "rayon_ourlet" in info:
        for i in range(n + 1, 2 * n + 1):
            cs[i] = ourlet
    else:
        cs[2] = ourlet
    xs = [p[0] for p in contour]; ys = [p[1] for p in contour]
    cx = (min(xs) + max(xs)) / 2
    piece = {"nom": nom, "couper": str(nb_les), "matiere": "", "contour": contour, "couture": cs,
             "droit_fil": ((cx, min(ys) + 3), (cx, max(ys) - 3)), "pliure": None, "crans": [], "lignes": [], "cotes": [],
             "_info": info}
    return piece


# ------------------------------------------------------------------ mise en page
def _bbox(pts):
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
    return min(xs), min(ys), max(xs), max(ys)


def _place(pieces, largeur_max, hauteur_max=None, marge=3.0):
    """Rangement en étagères. Retourne [(page, piece, dx, dy, coupe)] en cm."""
    items = []
    for pc in pieces:
        cp = contour_coupe(pc)
        x0, y0, x1, y1 = _bbox(cp)
        items.append((pc, cp, x0, y0, x1 - x0, y1 - y0))
    items.sort(key=lambda t: -t[5])
    places, page, x, y, h_etagere = [], 0, marge, marge, 0
    for pc, cp, x0, y0, w, h in items:
        if w + 2 * marge > largeur_max or (hauteur_max and h + 2 * marge > hauteur_max):
            print(f"⚠️ {pc['nom']} ({w:.0f} × {h:.0f} cm) dépasse la zone utile : elle sera coupée.")
        if x + w + marge > largeur_max and x > marge:
            x, y, h_etagere = marge, y + h_etagere + marge, 0
        if hauteur_max and y + h + marge > hauteur_max and y > marge:
            page, x, y, h_etagere = page + 1, marge, marge, 0
        places.append((page, pc, x - x0, y - y0, cp))
        x += w + marge
        h_etagere = max(h_etagere, h)
    return places


# ------------------------------------------------------------------ dessin (reportlab)
def _dessine_piece(cv, pc, dx, dy, cp, mm_par_cm, ox, oy, H_mm, police=7):
    """Dessine une pièce. ox, oy : origine en mm (coin haut gauche de la zone) ; y PDF vers le haut."""
    from reportlab.lib.colors import black, HexColor
    def T(p):
        return ox + (p[0] + dx) * mm_par_cm, H_mm - (oy + (p[1] + dy) * mm_par_cm)
    k = 72 / 25.4
    def ligne(pts, ferme=False, epais=0.6, tirets=None, couleur=black):
        cv.setStrokeColor(couleur); cv.setLineWidth(epais); cv.setDash(*(tirets or ([], 0)))
        pa = cv.beginPath(); q = [T(p) for p in pts]
        pa.moveTo(q[0][0] * k, q[0][1] * k)
        for a, b in q[1:]:
            pa.lineTo(a * k, b * k)
        if ferme:
            pa.close()
        cv.drawPath(pa, stroke=1, fill=0); cv.setDash([], 0)
    ligne(cp, True, 0.9)
    ligne(pc["contour"], True, 0.5, ([3, 2], 0))
    for li in pc.get("lignes", []):
        ligne(li, False, 0.5)
    if pc.get("pliure"):
        ligne(list(pc["pliure"]), False, 1.2, ([6, 2, 1, 2], 0), HexColor("#1E6FD9"))
    a, b = pc["droit_fil"]
    ligne([a, b], False, 0.6)
    (ax, ay), (bx, by) = T(a), T(b)
    ang = math.atan2(by - ay, bx - ax)
    for (px, py), s in (((ax, ay), 1), ((bx, by), -1)):
        for d in (0.4, -0.4):
            cv.line(px * k, py * k, (px + s * 3 * math.cos(ang + d)) * k, (py + s * 3 * math.sin(ang + d)) * k)
    s_list = _valeurs_couture(pc); c = pc["contour"]; n = len(c)
    for cr in pc.get("crans", []):
        i = min(range(n), key=lambda j: _dist_seg(cr, c[j], c[(j + 1) % n]))
        (x1, y1), (x2, y2) = c[i], c[(i + 1) % n]
        L = math.hypot(x2 - x1, y2 - y1) or 1
        signe = 1 if _aire(c) > 0 else -1
        nx, ny = ((y2 - y1) / L, -(x2 - x1) / L) if signe > 0 else (-(y2 - y1) / L, (x2 - x1) / L)
        si = s_list[i]
        ligne([(cr[0] + nx * si, cr[1] + ny * si), (cr[0] + nx * (si - 0.6), cr[1] + ny * (si - 0.6))], False, 1.0)
    for p1, p2, txt in pc.get("cotes", []):
        ligne([p1, p2], False, 0.3, ([1, 1.5], 0), HexColor("#777777"))
        mx, my = T(((p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2))
        cv.setFont("Helvetica", police * 0.85); cv.setFillColor(HexColor("#555555"))
        cv.drawCentredString(mx * k, (my + 1) * k, txt)
    x0, y0, x1, y1 = _bbox(pc["contour"])
    cx, cy = T(((x0 + x1) / 2, (y0 + y1) / 2))
    from reportlab.lib.colors import white
    lignes_txt = [pc["nom"].upper(), f"Couper {pc.get('couper', '')}"] + ([pc["matiere"]] if pc.get("matiere") else [])
    larg = max(cv.stringWidth(t, "Helvetica-Bold", police + 1) for t in lignes_txt) / k + 2 * police * 0.15
    haut = police * 0.65 * len(lignes_txt) + police * 0.4
    cv.setFillColor(white)
    cv.rect((cx - larg / 2) * k, (cy - haut + police * 0.85) * k, larg * k, haut * k, stroke=0, fill=1)
    cv.setFillColor(black)
    cv.setFont("Helvetica-Bold", police + 1); cv.drawCentredString(cx * k, (cy + police * 0.5) * k, pc["nom"].upper())
    cv.setFont("Helvetica", police)
    cv.drawCentredString(cx * k, (cy - police * 0.15) * k, f"Couper {pc.get('couper', '')}")
    if pc.get("matiere"):
        cv.drawCentredString(cx * k, (cy - police * 0.8) * k, pc["matiere"])


def _dist_seg(p, a, b):
    ax, ay = a; bx, by = b; px, py = p
    dx, dy = bx - ax, by - ay
    L2 = dx * dx + dy * dy or 1e-12
    t = max(0, min(1, ((px - ax) * dx + (py - ay) * dy) / L2))
    return math.hypot(px - ax - t * dx, py - ay - t * dy)


def planche_1_10(pieces, sortie, titre="", sous_titre=""):
    """Planche de patron au 1:10, PDF A3 paysage (+ SVG taille réelle). 1 cm réel = 1 mm."""
    from reportlab.pdfgen import canvas
    from reportlab.lib.colors import HexColor, black
    W, H = 420, 297
    k = 72 / 25.4
    zone_x, zone_y, zone_w, zone_h = 12, 30, W - 24, H - 42      # mm ; bande haute pour le titre
    places = _place(pieces, zone_w, zone_h)                      # 1 cm réel = 1 mm : mêmes nombres
    nb_pages = max(p[0] for p in places) + 1
    chemin = _p(sortie if sortie.endswith(".pdf") else sortie + ".pdf")
    cv = canvas.Canvas(chemin, pagesize=(W * k, H * k))
    for page in range(nb_pages):
        cv.setStrokeColor(HexColor("#DDDDDD")); cv.setLineWidth(0.25)
        g = 5
        x = zone_x
        while x <= zone_x + zone_w + 0.01:
            cv.line(x * k, (H - zone_y) * k, x * k, (H - zone_y - zone_h) * k); x += g
        y = zone_y
        while y <= zone_y + zone_h + 0.01:
            cv.line(zone_x * k, (H - y) * k, (zone_x + zone_w) * k, (H - y) * k); y += g
        cv.setFillColor(black)
        cv.setFont("Helvetica-Bold", 14); cv.drawString(12 * k, (H - 12) * k, titre or "Patron")
        cv.setFont("Helvetica", 8.5)
        cv.drawString(12 * k, (H - 18) * k, (sous_titre + "  ·  " if sous_titre else "") +
                      "Échelle un dixième (1:10) : 1 cm sur la planche = 10 cm réels · grille de 5 cm réels")
        cv.drawString(12 * k, (H - 23) * k, "Trait plein : coupe · pointillé : ligne de couture · bleu : pliure · flèche : droit-fil")
        rx, ry = W - 80, H - 18
        cv.setLineWidth(0.8); cv.line(rx * k, ry * k, (rx + 50) * k, ry * k)
        cv.setFont("Helvetica", 6.5)
        for i in range(6):
            cv.line((rx + 10 * i) * k, ry * k, (rx + 10 * i) * k, (ry + (2.5 if i % 5 == 0 else 1.5)) * k)
            cv.drawCentredString((rx + 10 * i) * k, (ry - 3.5) * k, f"{10 * i}")
        cv.drawString((rx + 52) * k, (ry - 1) * k, "cm réels")
        if nb_pages > 1:
            cv.drawRightString((W - 12) * k, 6 * k, f"Planche {page + 1}/{nb_pages}")
        for pg, pc, dx, dy, cp in places:
            if pg == page:
                _dessine_piece(cv, pc, dx, dy, cp, 1.0, zone_x, zone_y, H, police=6.5)
        cv.showPage()
    cv.save()
    svg = svg_taille_reelle(pieces, sortie.replace(".pdf", "") + ".svg")
    return chemin, svg, nb_pages


def pdf_taille_reelle(pieces, sortie, format="A0", titre=""):
    """PDF à l'échelle 1:1. format 'A0' (traceur, pièces jamais coupées) ou 'A4' (pages à assembler)."""
    from reportlab.pdfgen import canvas
    from reportlab.lib.colors import black, HexColor
    k = 72 / 25.4
    chemin = _p(sortie if sortie.endswith(".pdf") else sortie + ".pdf")
    def temoin(cv, W, H):
        cv.setStrokeColor(black); cv.setLineWidth(0.8)
        cv.rect(10 * k, 10 * k, 50 * k, 50 * k)
        cv.setFont("Helvetica", 9); cv.setFillColor(black)
        cv.drawString(10 * k, 63 * k, "Carré témoin 5 × 5 cm — imprimer à 100 %, sans mise à l'échelle")
    if format.upper() == "A0":
        W, H = 841, 1189
        places = _place(pieces, (W - 20) / 10, (H - 90) / 10)
        nb = max(p[0] for p in places) + 1
        cv = canvas.Canvas(chemin, pagesize=(W * k, H * k))
        for page in range(nb):
            cv.setFont("Helvetica-Bold", 16); cv.drawString(10 * k, (H - 14) * k, f"{titre}  ·  taille réelle  ·  page {page + 1}/{nb}")
            temoin(cv, W, H)
            for pg, pc, dx, dy, cp in places:
                if pg == page:
                    _dessine_piece(cv, pc, dx, dy, cp, 10.0, 10, 20, H, police=14)
            cv.showPage()
        cv.save()
        return chemin, nb
    # A4 : grande toile découpée en tuiles
    W, H = 210, 297
    mx, my = 10, 12
    uw, uh = W - 2 * mx, H - 2 * my - 8
    places = _place(pieces, 150)                          # toile de 1,5 m de large
    x1 = max(_bbox([(p[0] + dx, p[1] + dy) for p in cp])[2] for _, _, dx, dy, cp in places) + 3
    y1 = max(_bbox([(p[0] + dx, p[1] + dy) for p in cp])[3] for _, _, dx, dy, cp in places) + 3
    cols, rows = math.ceil(x1 * 10 / uw), math.ceil(y1 * 10 / uh)
    cv = canvas.Canvas(chemin, pagesize=(W * k, H * k))
    lettres = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    for r in range(rows):
        for c in range(cols):
            cv.saveState()
            pa = cv.beginPath(); pa.rect(mx * k, (H - my - uh) * k, uw * k, uh * k)
            cv.clipPath(pa, stroke=0, fill=0)
            for _, pc, dx, dy, cp in places:
                _dessine_piece(cv, pc, dx, dy, cp, 10.0, mx - c * uw, my - r * uh, H, police=12)
            cv.restoreState()
            cv.setStrokeColor(HexColor("#999999")); cv.setLineWidth(0.4); cv.setDash([2, 2], 0)
            cv.rect(mx * k, (H - my - uh) * k, uw * k, uh * k); cv.setDash([], 0)
            for (px, py) in ((mx, my), (mx + uw, my), (mx, my + uh), (mx + uw, my + uh)):
                cv.line((px - 4) * k, (H - py) * k, (px + 4) * k, (H - py) * k)
                cv.line(px * k, (H - py - 4) * k, px * k, (H - py + 4) * k)
            cv.setFont("Helvetica-Bold", 10); cv.setFillColor(black)
            cv.drawString(mx * k, (H - 8) * k, f"{titre}  ·  page {lettres[r % 26]}{c + 1}  (ligne {lettres[r % 26]}, colonne {c + 1} sur {rows} × {cols})")
            cv.setFont("Helvetica", 7)
            cv.drawString(mx * k, 5 * k, "Assembler bord à bord sur les traits gris · Carré témoin : page A1 · imprimer à 100 %, sans mise à l'échelle")
            if r == 0 and c == 0:
                cv.setStrokeColor(black); cv.setLineWidth(0.8)
                cv.rect((W - mx - 52) * k, (my + 10) * k, 50 * k, 50 * k)
                cv.drawString((W - mx - 52) * k, (my + 62) * k, "Carré témoin 5 × 5 cm")
            cv.showPage()
    cv.save()
    return chemin, rows * cols


def svg_taille_reelle(pieces, sortie):
    """SVG en centimètres réels (s'ouvre à la bonne taille dans Inkscape ou Illustrator)."""
    places = _place(pieces, 150)
    x1 = max(_bbox([(p[0] + dx, p[1] + dy) for p in cp])[2] for _, _, dx, dy, cp in places) + 3
    y1 = max(_bbox([(p[0] + dx, p[1] + dy) for p in cp])[3] for _, _, dx, dy, cp in places) + 3
    def path(pts, dx, dy, ferme=True):
        d = "M " + " L ".join(f"{x + dx:.3f},{y + dy:.3f}" for x, y in pts)
        return d + (" Z" if ferme else "")
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{x1:.2f}cm" height="{y1:.2f}cm" viewBox="0 0 {x1:.2f} {y1:.2f}">',
           '<rect width="100%" height="100%" fill="white"/>']
    for _, pc, dx, dy, cp in places:
        out.append(f'<g id="{pc["nom"]}">')
        out.append(f'<path d="{path(cp, dx, dy)}" fill="none" stroke="black" stroke-width="0.08"/>')
        out.append(f'<path d="{path(pc["contour"], dx, dy)}" fill="none" stroke="black" stroke-width="0.04" stroke-dasharray="0.4,0.25"/>')
        for li in pc.get("lignes", []):
            out.append(f'<path d="{path(li, dx, dy, False)}" fill="none" stroke="black" stroke-width="0.04"/>')
        if pc.get("pliure"):
            out.append(f'<path d="{path(list(pc["pliure"]), dx, dy, False)}" fill="none" stroke="#1E6FD9" stroke-width="0.08" stroke-dasharray="0.8,0.3,0.15,0.3"/>')
        a, b = pc["droit_fil"]
        out.append(f'<path d="{path([a, b], dx, dy, False)}" fill="none" stroke="black" stroke-width="0.05"/>')
        bx, by = _bbox(pc["contour"])[:2]
        cx = sum(_bbox(pc["contour"])[0::2]) / 2 + dx; cy = sum(_bbox(pc["contour"])[1::2]) / 2 + dy
        out.append(f'<text x="{cx:.2f}" y="{cy:.2f}" font-size="1.4" text-anchor="middle" font-family="Helvetica">{pc["nom"].upper()} — couper {pc.get("couper", "")}</text>')
        out.append("</g>")
    out.append("</svg>")
    chemin = _p(sortie)
    open(chemin, "w", encoding="utf-8").write("\n".join(out))
    return chemin


# ------------------------------------------------------------------ DXF (type AAMA, R12, cm)
def dxf_aama(pieces, sortie, style="atelier"):
    """DXF R12 en cm, une pièce par bloc. Calques : 1 coupe · 14 couture · 7 droit-fil · 8 lignes internes · 4 crans."""
    L = []
    def a(*xs):
        for x in xs:
            L.append(str(x))
    def poly(pts, calque, ferme=True):
        a(0, "POLYLINE", 8, calque, 66, 1, 70, 1 if ferme else 0)
        for x, y in pts:
            a(0, "VERTEX", 8, calque, 10, f"{x:.4f}", 20, f"{-y:.4f}", 30, 0)
        a(0, "SEQEND", 8, calque)
    def ligne(p, q, calque):
        a(0, "LINE", 8, calque, 10, f"{p[0]:.4f}", 20, f"{-p[1]:.4f}", 30, 0, 11, f"{q[0]:.4f}", 21, f"{-q[1]:.4f}", 31, 0)
    def texte(p, t, calque="1", h=1.0):
        a(0, "TEXT", 8, calque, 10, f"{p[0]:.4f}", 20, f"{-p[1]:.4f}", 30, 0, 40, h, 1, t)
    a(0, "SECTION", 2, "HEADER", 9, "$ACADVER", 1, "AC1009", 9, "$INSUNITS", 70, 5, 0, "ENDSEC")
    a(0, "SECTION", 2, "TABLES", 0, "TABLE", 2, "LAYER", 70, 5)
    for nom, coul in (("1", 7), ("14", 3), ("7", 5), ("8", 4), ("4", 1)):
        a(0, "LAYER", 2, nom, 70, 0, 62, coul, 6, "CONTINUOUS")
    a(0, "ENDTAB", 0, "ENDSEC")
    a(0, "SECTION", 2, "BLOCKS")
    places = _place(pieces, 150)
    noms = []
    for idx, (_, pc, dx, dy, cp) in enumerate(places):
        nom = "".join(ch if ch.isalnum() else "_" for ch in pc["nom"])[:28] + f"_{idx + 1}"
        noms.append((nom, dx, dy))
        a(0, "BLOCK", 8, "0", 2, nom, 70, 0, 10, 0, 20, 0, 30, 0, 3, nom)
        poly(cp, "1")
        poly(pc["contour"], "14")
        ligne(*pc["droit_fil"], "7")
        for li in pc.get("lignes", []):
            poly(li, "8", ferme=False)
        if pc.get("pliure"):
            ligne(*pc["pliure"], "8")
        c = pc["contour"]; n = len(c); s = _valeurs_couture(pc); sg = 1 if _aire(c) > 0 else -1
        for cr in pc.get("crans", []):
            i = min(range(n), key=lambda j: _dist_seg(cr, c[j], c[(j + 1) % n]))
            (x1, y1), (x2, y2) = c[i], c[(i + 1) % n]
            Ln = math.hypot(x2 - x1, y2 - y1) or 1
            nx, ny = ((y2 - y1) / Ln, -(x2 - x1) / Ln) if sg > 0 else (-(y2 - y1) / Ln, (x2 - x1) / Ln)
            ligne((cr[0] + nx * s[i], cr[1] + ny * s[i]), (cr[0] + nx * (s[i] - 0.6), cr[1] + ny * (s[i] - 0.6)), "4")
        x0, y0, x1b, y1b = _bbox(c)
        texte(((x0 + x1b) / 2, (y0 + y1b) / 2), f"Piece Name: {pc['nom']}")
        texte(((x0 + x1b) / 2, (y0 + y1b) / 2 + 1.5), f"Quantity: {pc.get('couper', '')}")
        if pc.get("matiere"):
            texte(((x0 + x1b) / 2, (y0 + y1b) / 2 + 3), f"Category: {pc['matiere']}")
        a(0, "ENDBLK", 8, "0")
    a(0, "ENDSEC", 0, "SECTION", 2, "ENTITIES")
    for nom, dx, dy in noms:
        a(0, "INSERT", 8, "0", 2, nom, 10, f"{dx:.4f}", 20, f"{-dy:.4f}", 30, 0)
    a(0, "ENDSEC", 0, "EOF")
    chemin = _p(sortie if sortie.endswith(".dxf") else sortie + ".dxf")
    open(chemin, "w", encoding="ascii", errors="replace").write("\n".join(L) + "\n")
    return chemin


def verifie_dxf(chemin, nb_pieces):
    txt = open(_p(chemin), encoding="ascii").read().split("\n")
    nb = sum(1 for i, l in enumerate(txt) if l == "BLOCK" and i > 0 and txt[i - 1] == "0")
    return {"blocs": nb, "pieces": nb_pieces, "ok": nb == nb_pieces}


def apercu(pdf, page=1, sortie=None, dpi=60):
    """Aperçu PNG d'une page de PDF (nécessite pdftoppm ; sinon ouvrir le PDF)."""
    import subprocess
    base = _p(sortie or os.path.splitext(os.path.basename(pdf))[0] + "_apercu")
    subprocess.run(["pdftoppm", "-png", "-r", str(dpi), "-f", str(page), "-l", str(page), "-singlefile", _p(pdf), base], check=True)
    return base + ".png"
