# Étape 7 — Dessin technique et patronnage

À lire avant d'ouvrir l'étape 7. Outils : `scripts/patron_tools.py` (patron, contrôles, PDF, SVG, DXF) et `scripts/atelier_tools.py` (planche technique).

**Principe qui commande toute l'étape : le patron ne se génère jamais en image.** Il se **calcule** à partir d'un barème et des règles de coupe à plat, se dessine en vectoriel à l'échelle par code, et son **tableau de cotes fait foi**, jamais une image. Le seul élément généré par un modèle d'image est le dessin technique au trait.

**Ce qui fait loi pour la forme, dans l'ordre :** la fiche technique validée (mesures, ourlets, fermeture) → le dessin à plat couleur (placement des zones, coutures, ADN) → le prototype validé (rendu seulement ; s'il a été accepté « avec tolérance », la fiche a déjà été mise à jour d'après lui).

---

## 7a. Choix de départ

> **Étape 7 — Dessin technique et patronnage.** Pour quels looks ?
> **1.** Tous les looks · **2.** Le look fondateur d'abord ★ · **3.** Une sélection
> Taille : **38 standard** ★ · une autre taille (34 à 46) · des mensurations sur mesure.
> Livrables : dessin technique + fiche · + patron coté (PDF 1:10, PDF taille réelle, DXF) · + CLO 3D.

L'étape s'ouvre sur un look dès que son prototype est validé ; elle n'exige pas que toute la collection soit finie. Les mensurations retenues sont **affichées et validées avant tout calcul**. Une seule taille est tracée ; la gradation vient sur demande.

---

## 7b. Dessin technique au trait — 2 looks par image (16:9)

Une génération par paire de looks (ou look seul). Kit de références, préparé par toi, dans l'ordre de jointure (mode carnet : envoyé au créateur avec le prompt) :

| Réf. | Fichier | Rôle |
|---|---|---|
| IMAGE 1 | `LA_plat` | FORME face + dos du look A (fait loi) |
| IMAGE 2 | `LA_proto` validé | Construction réelle du look A (coutures, finitions) |
| IMAGE 3 | `LB_plat` | FORME du look B |
| IMAGE 4 | `LB_proto` validé | Construction réelle du look B |

```
Create an image now.

REFERENCES — each image is used ONLY for its stated role:
IMAGE 1 — SHAPE OF OUTFIT A: a flat color technical drawing, FRONT left, BACK right. Use it for the outline, proportions and the exact placement of every seam, zone, signature element and the closure. Ignore its colors, its print and the grey figure. Its blue dashed line marks the closure: draw a real closure line there.
IMAGE 2 — CONSTRUCTION OF OUTFIT A: the approved prototype photograph. Use it only to read how the garment is really built: seams, darts, pleats, topstitching, hems, closure. Ignore the model, the setting, the colors and the print.
IMAGE 3 — SHAPE OF OUTFIT B: [même rôle que IMAGE 1].
IMAGE 4 — CONSTRUCTION OF OUTFIT B: [même rôle que IMAGE 2].
The written description below always wins over any reference.

OUTPUT: ONE image, horizontal 16:9, a technical fashion flat sketch sheet on a pure white #FFFFFF background, four drawings in one row, same scale, garments aligned on the same top line: from the LEFT SIDE OF THE IMAGE to the RIGHT — OUTFIT A FRONT, OUTFIT A BACK, a wider empty gap exactly at the horizontal center, OUTFIT B FRONT, OUTFIT B BACK. Each outfit occupies exactly one half of the image. Each garment is drawn flat as if laid on a table: no body, no figure, no head, no arms, no mannequin; sleeves and straps spread open and flat; perfectly symmetrical unless the garment is asymmetric. Each garment fills about 80 % of the image height. Separate pieces of one outfit (top and bottom) are drawn one above the other in the same column, the top piece above.
STYLE: black #111111 line drawing only — even outlines about 2 px; thinner lines for seams, darts, pleats and the hem line; dashed lines for topstitching; small circles for buttons; a thin solid line with a small pull for a zip. No shading, no color fill, no gray fill, no gradient, no texture, no shadow, no perspective. Printed zones are left white, outlined only.

OUTFIT A (left half):
LINES TO SHOW — FRONT: [chaque couture, pince, pli, fente, ourlet, surpiqûre, fermeture, à sa place, avec comptages exacts]. BACK: [surfaces continues, coutures, fente, fermeture ; ne jamais nommer un élément absent].
PROPORTIONS (drawing instruction, never displayed): [longueur totale, largeur poitrine, taille, bas, en cm].
OUTFIT B (right half):
[même structure]

The two outfits never share or swap any element.
NO TEXT anywhere: no dimension lines, no measurements, no arrows, no labels, no numbers, no logo, no watermark.
```

**Look seul :** même gabarit, une seule tenue, FRONT à gauche, BACK à droite, format 3:2.

**Contrôle :** concordance ligne à ligne avec la fiche technique et le dessin à plat couleur (mêmes coutures, même nombre de pinces, de plis, de boutons, même fermeture, même dos). Verdict et tolérance comme ailleurs ; un trait manquant ou en trop sur un élément d'ADN n'est jamais toléré.

**Après validation :** tu découpes le dessin par code (`decoupe_paire`, noms `L[n]_technique`) et compose la **planche technique** (`planche_technique` dans `atelier_tools.py`) : le dessin, et posés par code : le cartouche (collection, look, taille, version, date), les cotes principales numérotées, les matières et la nomenclature. Les cotes vont sur la planche par code, jamais dans l'image générée.

---

## 7c. Fiche technique de production (complète la fiche de l'étape 3)

```
DOSSIER TECHNIQUE — L[n] "[Nom]" · taille [38] · v1
① Dessin technique (L[n]_technique vN) · fiche étape 3 (vN)
② Mesures finies (cm) avec tolérance ± : longueur totale, tour de poitrine fini, tour de taille fini, tour de hanches fini, largeur de bas, longueur de manche, ouverture de manche
③ Détails de construction, numérotés comme sur la planche : coutures (type : piquée-ouverte, anglaise, rabattue, surjetée), pinces, plis, finitions de bord, surpiqûres (longueur de point)
④ Fermetures : type · emplacement · longueur · fournisseur si connu
⑤ Nomenclature : tissus (réf. imprimé, laize, métrage estimé à confirmer par le modéliste), doublure, entoilage, fournitures (fil, boutons, glissière, baleines)
⑥ Gamme de montage (ordre des opérations)
⑦ Points de vigilance en confection (raccord d'imprimé, sens du motif, ADN à cheval sur plusieurs pièces)
```

---

## 7d. Le patron coté — méthode

1. **Blocs de base** nécessaires (corsage, manche, jupe, pantalon), tracés à la taille validée.
2. **Aisances** zone par zone, selon le niveau d'ajustement de la fiche. Une maille extensible peut aller en aisance négative ; un tissu rigide, jamais.
3. **Transformations** selon la fiche : pivot ou déplacement de pince, cintrage, évasement, découpes, empiècements, fentes, godets, volants, drapés. Principe : **une base fonctionnelle + des effets rapportés**, on ne force pas l'effet dans le bloc de base.
4. **Valeurs de couture et ourlets.**
5. **Contrôles.** Tant qu'un contrôle échoue, le patron n'est pas livré : corrige dans l'ordre indiqué, puis refais tous les contrôles. Les contrôles se calculent par code avec `patron_tools.py` (`longueur`, `longueur_bord`, `controle`), jamais à l'œil.

**Faisabilité au patron** — à signaler au créateur **avant** de calculer, avec la valeur proposée :
- **bustier sans bretelles** : bord haut au moins 6 cm au-dessus de la ligne de poitrine au milieu devant ; corset intérieur baleiné ; tour haut égal ou 1 à 3 cm inférieur au tour de corps sur matière qui s'étire ;
- **jupe très évasée ou rigide** : développement en **tronc de cône** (lés en secteurs d'anneau : rayon intérieur, rayon d'ourlet, angle, calculés depuis le tour du haut, le tour d'ourlet et la longueur — `secteur_anneau()`), structure prévue (baleines, cerceau, entoilage) ;
- **ajours et découpes** : lisière pleine d'au moins 1 cm le long de chaque couture ;
- **élément d'ADN qui traverse plusieurs pièces** : livré en **gabarit** à reporter après montage, avec sa pièce d'insert.

**Tableau de cotes (livrable qui fait foi, en .md) :**
```
PATRON — L[n] "[Nom]" · taille [38] · v1
① Mensurations retenues
② Aisances par zone
③ Liste des pièces : nom · nombre à couper · matière · pliure oui/non
④ Cotes de chaque pièce : points de construction (x, y en cm), largeurs, longueurs, pinces, courbes
⑤ Valeurs de couture et ourlets
⑥ Crans, droit-fil, repères
⑦ Contrôles : valeur attendue · valeur mesurée · ✅ / ❌
⑧ Ordre de montage
```

**Contrôles obligatoires**

| Contrôle | Règle | Si ça échoue |
|---|---|---|
| Tour de poitrine | (somme des largeurs à la ligne de poitrine − pinces et découpes ouvertes à cette ligne) × 2 = tour de poitrine + aisance poitrine | ajuster la largeur des panneaux |
| Tour de taille | (somme des largeurs à la taille − pinces et côté) × 2 = tour de taille + aisance taille ; reprise par panneau = `largeur du panneau − (¼ taille + ¼ aisance taille)` | ajuster la répartition de la reprise, jamais la largeur de poitrine |
| Tour de hanches | (somme des largeurs à la ligne de hanches) × 2 = tour de hanches + aisance hanches | ajuster la largeur des panneaux de bas |
| Coutures appariées | deux bords cousus ensemble ont la même longueur, à l'embu déclaré près | rallonger le bord court, jamais raccourcir le long |
| Tête de manche | courbe de tête = tour d'emmanchure + 2 à 4 cm d'embu | largeur de manche d'abord, puis hauteur de tête, puis refaire le contrôle |
| Encolure | encolure dos + encolure devant = longueur du col, de la parementure ou du biais | ajuster la pièce de finition |
| Enfilage | sans fermeture : tour de la plus petite ouverture d'enfilage ≥ tour de hanches + 2 cm | prévoir une fermeture ou une fente |

---

## 7e. Les sorties du patron (toutes produites par code, toutes depuis les mêmes coordonnées)

| Fichier | Usage | Fonction |
|---|---|---|
| `L[n]_patron_v1.md` | tableau de cotes, **fait foi** | rédigé par toi |
| `L[n]_patron_1-10.pdf` (A3 paysage) + `.svg` | lecture, contrôle, dossier | `planche_1_10()` |
| `L[n]_patron_reel_A0.pdf` (défaut) ou `_A4.pdf` (à assembler, sur demande) | tracer et couper en atelier | `pdf_taille_reelle()` |
| `L[n]_patron.dxf` (type AAMA, cm, une pièce par bloc, calques 1 coupe · 14 couture · 7 droit-fil · 8 lignes internes · 4 crans) | import CLO 3D ou CAO | `dxf_aama()` |

Règles de la planche 1:10 : toutes les pièces sur une planche, échelle écrite en toutes lettres, grille de 5 cm réels en fond, réglette de 50 cm réels graduée tous les 10 cm ; pour chaque pièce : nom, nombre à couper, flèche de droit-fil, ligne de pliure, crans, pinces, contour de coupe en trait plein, contour fini en pointillé, cotes principales.

PDF taille réelle : chaque page porte un **carré témoin de 5 × 5 cm** et « imprimer à 100 %, sans mise à l'échelle ». En A0, une pièce n'est jamais coupée entre deux pages ; en A4, repères d'assemblage et numéros de page (ligne-colonne).

**Avant de livrer, vérifie :** aperçu de la planche (image), nombre de pages, nombre de blocs du DXF = nombre de pièces (`verifie_dxf()`). Présente les fichiers ; propose en une ligne de les enregistrer dans le projet.

Mode carnet sans exécution de code : donne le tableau de cotes complet et le code SVG à enregistrer en `.svg` (ouvrable dans Inkscape ou Illustrator, qui exportent en PDF à l'échelle) ; annonce que le DXF devra être produit autrement.

---

## 7f. CLO 3D (seulement si le créateur l'utilise)

Marche à suivre numérotée, adaptée à la pièce, avec les valeurs calculées :
1. Nouveau projet, unités en centimètres.
2. Avatar : entrer les mensurations de la taille retenue.
3. Import : Fichier > Importer > DXF, unité cm, format AAMA, « Remove Non-Grading Points » ; lignes internes d'ajours : clic droit → Convert to Hole.
4. Disposer les pièces avec les points d'arrangement (devant, dos, côtés, bras).
5. Coudre : **liste ordonnée des coutures**, `pièce A · bord ↔ pièce B · bord — longueur — embu` (épaules, côtés, manches, finitions).
6. Tissus : preset proche de chaque matière, puis grammage, épaisseur, raideur, élasticité ; **avant** la simulation.
7. Simuler, vérifier qu'aucune pièce n'est piégée, monter en qualité.
8. Imprimés : texture à plat (`ref_I1`), **taille réelle du motif en cm**, sens par rapport au droit-fil.
9. Contrôler : carte de tension et d'aisance, zones à surveiller pour cette pièce, aplomb des longueurs vs fiche.
10. Exporter : projet, rendus.

Les menus exacts varient selon la version de CLO : demande la version avant de donner des chemins précis. Si le créateur renvoie une capture CLO, compare-la à la fiche et au prototype avec le verdict habituel.

---

## Barème femme (cm) — base de travail, celui du créateur prime toujours

| Mesure | 34 | 36 | 38 | 40 | 42 | 44 | 46 |
|---|---|---|---|---|---|---|---|
| Tour de poitrine | 80 | 84 | 88 | 92 | 96 | 100 | 104 |
| Tour de taille | 62 | 66 | 70 | 74 | 78 | 82 | 86 |
| Tour de hanches | 88 | 92 | 96 | 100 | 104 | 108 | 112 |
| Stature | 166 | 167 | 168 | 169 | 170 | 171 | 172 |
| Longueur taille dos | 40,0 | 40,5 | 41,0 | 41,5 | 42,0 | 42,5 | 43,0 |
| Longueur taille devant | 42,6 | 43,3 | 44,0 | 44,7 | 45,4 | 46,1 | 46,8 |
| Carrure dos | 33 | 34 | 35 | 36 | 37 | 38 | 39 |
| Carrure devant | 31 | 32 | 33 | 34 | 35 | 36 | 37 |
| Longueur d'épaule | 11,9 | 12,2 | 12,5 | 12,8 | 13,1 | 13,4 | 13,7 |
| Tour d'encolure | 34 | 35 | 36 | 37 | 38 | 39 | 40 |
| Hauteur de poitrine | 24,4 | 25,2 | 26,0 | 26,8 | 27,6 | 28,4 | 29,2 |
| Écart de poitrine | 17,0 | 17,5 | 18,0 | 18,5 | 19,0 | 19,5 | 20,0 |
| Longueur de bras | 57,4 | 58,2 | 59,0 | 59,8 | 60,6 | 61,4 | 62,2 |
| Tour de bras | 25,0 | 26,5 | 28,0 | 29,5 | 31,0 | 32,5 | 34,0 |
| Tour de poignet | 15,0 | 15,5 | 16,0 | 16,5 | 17,0 | 17,5 | 18,0 |
| Hauteur des hanches | 19,50 | 19,75 | 20,00 | 20,25 | 20,50 | 20,75 | 21,00 |
| Montant (taille → siège) | 26,2 | 26,6 | 27,0 | 27,4 | 27,8 | 28,2 | 28,6 |
| Taille → sol | 103,0 | 103,5 | 104,0 | 104,5 | 105,0 | 105,5 | 106,0 |
| Entrejambe | 76,8 | 76,9 | 77,0 | 77,1 | 77,2 | 77,3 | 77,4 |
| Taille → genou | 57,2 | 57,6 | 58,0 | 58,4 | 58,8 | 59,2 | 59,6 |

Identités à ne jamais casser : montant + entrejambe = taille → sol ; longueur taille devant > longueur taille dos ; écart genou-sol proche de 46 cm. Au-delà du 46, la gradation n'est plus linéaire : ne prolonge pas le tableau sans le dire. Le barème est aussi dans `patron_tools.BAREME`.

## Blocs de base (demi-patron, ajusté)

**Corsage** — un rectangle demi-dos, un demi-devant.
- Largeur de chacun : ¼ tour de poitrine + 1 cm (4 cm d'aisance au total).
- Hauteur : longueur taille dos (dos), longueur taille devant (devant).
- Profondeur d'emmanchure sous la base du cou : tour de poitrine ÷ 8 + 10,5 cm.
- Carrure dos à ⅓ de cette profondeur ; carrure devant à ½.
- Ligne de hanches : taille + hauteur des hanches.
- Encolure dos : largeur = tour d'encolure ÷ 6 + 0,5 ; hauteur 2. Encolure devant : même largeur ; profondeur = largeur + 1.
- Tombant d'épaule : 4 cm au dos, 4,5 cm au devant.
- Pince d'omoplate : 1,2 cm, à 8 cm du milieu dos, pointe à 8 cm sous l'épaule ; épaule dos tracée à longueur d'épaule + pince (13,7 en 38).
- Pince de poitrine : pointe à la hauteur de poitrine et à ½ écart de poitrine du milieu devant (9 cm en 38), arrêtée 2 cm avant.
- Reprise à la taille par panneau : `largeur − (¼ taille + ¼ aisance taille)` ; en 38 : 23 − 18 = 5 cm ; répartition côté 35 % (1,5 cm max), pince dos 30 %, pince devant 35 %.

**Manche** — largeur : tour de bras + 4 ; hauteur de tête : (profondeur d'emmanchure − tombant dos) × ¾ ; longueur : longueur de bras. Embu de tête entre 2 et 4 cm : < 2 → élargir de 1 cm ; > 4 → rétrécir de 1 cm ; puis seulement la hauteur de tête.

**Jupe droite** — largeur de chaque panneau : ¼ hanches + 1 ; ligne de hanches à la hauteur des hanches ; reprise par panneau `largeur − (¼ taille + ¼ aisance taille)` (en 38 : 25 − 18 = 7) répartie côté 50 %, pince dos 35 %, pince devant 15 % ; pinces 14 cm au dos, 10 cm au devant. Tracée par `bloc_jupe_droite()`.

**Pantalon** — demi-devant à la hanche : ¼ hanches + 0,5 ; demi-dos : ¼ hanches + 1,5 ; fourche à la hauteur du montant ; fourche devant : hanches ÷ 20 ; dos : hanches ÷ 10 ; longueur : taille → sol − 2 ; reprise par panneau même formule (en 38 : 6,5 devant, 7,5 dos).

**Aisances**

| Ajustement | Poitrine | Taille | Hanches |
|---|---|---|---|
| Près du corps | 0 à 2 | 0 à 1 | 0 à 2 |
| Ajusté | 4 | 2 | 4 |
| Semi-ajusté | 6 à 8 | 4 | 6 |
| Ample | 10 et + | 8 et + | 10 et + |

**Valeurs de couture par défaut :** 1 cm assemblage ; 1,5 cm côtés ; 1 cm encolure et emmanchure ; ourlet 4 cm jupe ou robe, 3 cm manche, 2 cm volant. Toute autre valeur est déclarée dans la fiche.

**Traduction des formes :** fourreau = corsage cintré prolongé, aisance poitrine 2 ; trapèze = pince poitrine pivotée vers l'ourlet puis évasement ; sirène = cintré jusqu'à mi-cuisse puis évasement depuis une ligne déclarée ; empire = coupe sous poitrine, bas froncé ou évasé ; godet = triangles insérés dans les découpes ; palazzo = pantalon élargi depuis la fourche ; sarouel = montant rallongé, entrejambe raccourci, fronces taille et chevilles ; portefeuille = devant prolongé du croisement déclaré, lien ancré dans la couture de côté.
