# Installer Atelier Collection V5.3 dans ChatGPT

## Le principe : deux pièces, pas une

| Pièce | Contenu | Où elle va |
|---|---|---|
| `CHARGEUR_ATELIER_COLLECTION.txt` (≈ 6 000 caractères) | La procédure : ordre imposé, règles absolues, génération, références, patron, carnet | Champ **Instructions** |
| `SYSTEME_ATELIER_COLLECTION.md` | Les données : étapes détaillées, gabarits de prompts, table des négatifs, contrôle qualité, patronage, barème, scripts | **Connaissances** |

Un fichier de connaissance est lu par fragments, quand le modèle en a besoin. Tout ce qui doit s'appliquer à chaque fois est donc dans le chargeur ; le reste est cherché à la demande.

## Créer le GPT personnalisé

1. **Explorer les GPT** → **Créer** → onglet **Configurer** (pas l'assistant conversationnel : il réécrit les instructions).
2. **Nom** : « Atelier Collection — Directeur de collection ».
3. **Instructions** : coller tout le contenu de `CHARGEUR_ATELIER_COLLECTION.txt`. Le compteur doit rester sous 8 000 caractères.
4. **Connaissances** : téléverser `SYSTEME_ATELIER_COLLECTION.md`.
5. **Fonctionnalités** : activer **Génération d'images** (le directeur génère lui-même) et **Interprétation du code et analyse des données** (découpes, planches, lookbook, patron). Sans le code, les étapes 5 à 7 ne fonctionnent pas.
6. **Amorces de conversation** : « Je crée une collection » · « Une seule pièce » · « Voici des tenues qui m'inspirent » · « Je veux le patron d'une pièce déjà dessinée ».
7. Faire les 4 tests ci-dessous avant de partager.

Les libellés des menus peuvent varier selon votre offre ChatGPT.

## Protocole de test — 4 points

**Test 1 — l'ordre est tenu.** Écrire d'emblée « fais-moi le lookbook ». L'agent doit dire ce qui manque et proposer de commencer par l'étape 1, sans générer d'image. S'il génère, le chargeur est tronqué.

**Test 2 — une image, sans texte, au bon format.** Lancer une pièce unique jusqu'au prototype. Vérifier : une seule image par message, arrêt pour validation, aucun texte ni légende dans l'image, prototype en 3:2 avec face à gauche, dos au centre et 3 gros plans à droite.

**Test 3 — les références sont demandées.** Juste avant le prototype, l'agent doit donner une liste numérotée des fichiers à joindre (dessin à plat, imprimé, détails, muse), avec le rôle de chacun. S'il génère sans la demander, le chargeur n'a pas été lu en entier.

**Test 4 — le patron est calculé.** Demander « fais-moi le patron en image ». L'agent doit refuser l'image, faire valider les mensurations, puis livrer un tableau de contrôles (taille, hanches, coutures appariées…) avec ✅, et les fichiers PDF 1:10, PDF taille réelle et DXF. Imprimer la page taille réelle à 100 % et mesurer le carré témoin : 5 cm exactement.

## Bon à savoir

- Budget pour 8 looks : ≈ 16 images jusqu'au lookbook, + 4 pour les dessins techniques. Le patron ne consomme aucune image.
- Gardez chaque image validée : vous la rejoindrez comme référence.
- Aux points de passage, tapez « pack » : un .zip pour reprendre dans une conversation neuve sans dérive.
- Le barème fourni (taille 38) est une base : donnez le vôtre s'il existe. Faites une toile d'essai avant de couper le tissu définitif.

## Mettre à jour

Une règle modifiée dans le chargeur doit l'être aussi dans le fichier système, sinon le chargeur gagne en silence. Pour remplacer le fichier de connaissance, supprimer l'ancien avant de téléverser le nouveau.
