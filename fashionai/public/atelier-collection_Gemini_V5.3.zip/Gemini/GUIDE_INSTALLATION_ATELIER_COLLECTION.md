# Installer Atelier Collection V5.3 dans Gemini

## Le principe : deux pièces, pas une

| Pièce | Contenu | Où elle va |
|---|---|---|
| `CHARGEUR_ATELIER_COLLECTION.txt` (≈ 6 000 caractères) | La procédure : ordre imposé, règles absolues, génération, références, patron, carnet | Champ **Instructions** du Gem |
| `SYSTEME_ATELIER_COLLECTION.md` | Les données : étapes détaillées, gabarits de prompts, table des négatifs, contrôle qualité, patronage, barème, scripts | **Connaissances** du Gem |

Un fichier de connaissance est lu par fragments, quand le modèle en a besoin. Tout ce qui doit s'appliquer à chaque fois est donc dans le chargeur.

## Créer le Gem

1. **Gemini** → **Explorer les Gems** → **Nouveau Gem**.
2. **Nom** : « Atelier Collection — Directeur de collection ».
3. **Instructions** : coller tout le contenu de `CHARGEUR_ATELIER_COLLECTION.txt`.
4. **Connaissances** : téléverser `SYSTEME_ATELIER_COLLECTION.md`.
5. Enregistrer, puis faire les 4 tests ci-dessous.

La génération d'images et l'exécution de code dans un Gem dépendent de votre abonnement et de votre région ; les libellés peuvent varier.

## Les étapes qui demandent du code (5, 6 et 7)

Découpes, line-up réaliste, lookbook-planche et patron se font par code, jamais par génération d'image.
- **Si Gemini exécute le code dans la conversation**, il le fait lui-même.
- **Sinon, Google Colab** (gratuit) : ouvrez colab.research.google.com → Nouveau notebook. Le Gem vous donne un bloc unique à coller dans une cellule et la liste des images à déposer dans le panneau **Fichiers** (icône dossier à gauche). Exécutez la cellule ; les PDF, PNG, SVG et DXF apparaissent dans ce même panneau, clic droit → Télécharger.
- Pour une planche simple, le Gem peut aussi passer par **Canvas** (page imprimable).

## Protocole de test — 4 points

**Test 1 — l'ordre est tenu.** Écrire d'emblée « fais-moi le lookbook ». Le Gem doit dire ce qui manque et proposer de commencer par l'étape 1, sans générer d'image.

**Test 2 — une image, sans texte, au bon format.** Lancer une pièce unique jusqu'au prototype. Vérifier : une seule image par message, arrêt pour validation, aucun texte dans l'image, prototype en 3:2 avec face à gauche, dos au centre et 3 gros plans à droite. Gemini a tendance à reprendre la dernière image de la conversation : si le prototype ressemble trop à l'image précédente, vérifiez que les références ont bien été jointes au message « go ».

**Test 3 — les références sont demandées.** Juste avant le prototype, le Gem doit donner une liste numérotée des fichiers à joindre (dessin à plat, imprimé, détails, muse), avec le rôle de chacun.

**Test 4 — le patron est calculé.** Demander « fais-moi le patron en image ». Le Gem doit refuser l'image, faire valider les mensurations, puis passer par le code (ici ou dans Colab) : tableau de contrôles avec ✅, PDF 1:10, PDF taille réelle, DXF. Imprimer la page taille réelle à 100 % et mesurer le carré témoin : 5 cm exactement.

## Bon à savoir

- Budget pour 8 looks : ≈ 16 images jusqu'au lookbook, + 4 pour les dessins techniques. Le patron ne consomme aucune image.
- Gardez chaque image validée : vous la rejoindrez comme référence.
- Aux points de passage, tapez « pack » : un bloc texte à copier (fiches et carnet) pour reprendre dans une conversation neuve, avec vos images validées.
- Le barème fourni (taille 38) est une base : donnez le vôtre s'il existe. Faites une toile d'essai avant de couper le tissu définitif.

## Mettre à jour

Une règle modifiée dans le chargeur doit l'être aussi dans le fichier système. Pour remplacer le fichier de connaissance, supprimer l'ancien du Gem avant de téléverser le nouveau.
